#include <stdio.h>
#include <omp.h>

int main() {
    int array1[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    int array2[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int result[16];
    
    // This directive is used to parallelize only a single loop,
    // and since we only need to parallelize the addition part as per the question,
    // it is the most suitable choice here.
    #pragma omp parallel for
    for (int i = 0; i < 16; i++) {
        result[i] = array1[i] + array2[i];
    }
    
    // This loop runs serially to display the result.
    for (int i = 0; i < 16; i++) {
        printf("%d ", result[i]);
    }
    printf("\n");
    
    return 0;
}


    


