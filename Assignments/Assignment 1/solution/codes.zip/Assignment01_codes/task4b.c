#include <stdio.h>
#include <omp.h>

int main() {
    int array1[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    int array2[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int result1 = 0, result2 = 0;
    
    // Version 2: Using atomic operations 
    #pragma omp parallel num_threads(16)
    {
        // First loop with atomic
      // atomic operations are used to ensure that  
        // the updates to result1 are done safely
        //  it is different from reduction  as it does not 
        // create a private copy of result1 for each thread
        //  but rather updates the shared variable directly
        //  this can be less efficient than reduction
        #pragma omp for
        for (int i = 0; i < 16; i++) {
            #pragma omp atomic
            result1 += array1[i];
        }
        
        // Barrier here is implicit at the end of the for construct
        
        // Only proceed with second loop if condition is met
        #pragma omp single
        {
            if (result1 > 10) {
                result2 = result1;
            }
        }
        
        // Second loop with atomic if condition was met
        if (result1 > 10) {
            #pragma omp for
            for (int i = 0; i < 16; i++) {
                #pragma omp atomic
                result2 += array2[i];
            }
        }
    }
    
    printf("Using atomic: %d\n", result2);
    
    return 0;
}




































