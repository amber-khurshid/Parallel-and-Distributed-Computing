#include <stdio.h>
#include <omp.h>

int main() {
    int array1[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    int array2[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int result[16];
    
    // This creates a team of threads that will stay active for the whole block
    // Using this approach when you have multiple operations keeps the same threads around
    // instead of creating and destroying them multiple times
    #pragma omp parallel
    {
        // This distributes the loop iterations among the existing threads
        // Each thread gets a chunk of the array to process
        #pragma omp for
        for (int i = 0; i < 16; i++) {
            result[i] = array1[i] + array2[i];
        }
        
        // Every thread reaches this point, but we only want thread 0 to print
        // Without this check, we'd get multiple copies of the output
        if (omp_get_thread_num() == 0) {
		
            // Only the thread with ID 0 executes this code
            for (int i = 0; i < 16; i++) {
                printf("%d ", result[i]);
            }
            printf("\n");
        }
    }
    return 0;
}
