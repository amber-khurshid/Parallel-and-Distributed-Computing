#include <stdio.h>

int main() {
    int thread_id = 0;  
    printf("Hello, World! This is thread %d\n", thread_id);
    return 0;
}
