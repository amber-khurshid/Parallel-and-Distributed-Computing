#include <stdio.h>
#include <omp.h>

int main() {
    int array1[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    int array2[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
    int result[16];
    
    // Get max threads and use half
    int max_threads = omp_get_max_threads();
    omp_set_num_threads(max_threads / 2);
    
    // Parallel for with half threads
    #pragma omp parallel for
    for (int i = 0; i < 16; i++) {
        result[i] = array1[i] + array2[i];
    }
    
    // Print results
    for (int i = 0; i < 16; i++) {
        printf("%d ", result[i]);
    }
    printf("\n");
    
    return 0;
}


// #include <stdio.h>
// #include <omp.h>

// int main() {
//     int array1[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
//     int array2[16] = {16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
//     int result[16];
    
//     #pragma omp parallel
//     {
//         // Only use half the threads based on thread ID
//         int thread_id = omp_get_thread_num();
//         int total_threads = omp_get_num_threads();
//         int active_threads = total_threads / 2;
        
//         if (thread_id < active_threads) {
//             for (int i = thread_id; i < 16; i += active_threads) {
//                 result[i] = array1[i] + array2[i];
//             }
//         }
//     }
    
//     // Print results
//     for (int i = 0; i < 16; i++) {
//         printf("%d ", result[i]);
//     }
//     printf("\n");
    
//     return 0;
// }
