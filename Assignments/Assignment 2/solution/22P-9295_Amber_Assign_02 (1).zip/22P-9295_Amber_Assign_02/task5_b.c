#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    int rank, size, value;
    MPI_Request request;
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double start_time, end_time;

    MPI_Barrier(MPI_COMM_WORLD);  // Synchronize before timing
    start_time = MPI_Wtime();

    if (rank == 0) {
        // Master sends a value to all workers using non-blocking send
        for (int i = 1; i < size; i++) {
            value = i * 10;
            MPI_Isend(&value, 1, MPI_INT, i, 0, MPI_COMM_WORLD, &request);
            MPI_Wait(&request, &status);  // Ensure send completes
        }

        // Master receives value using non-blocking receive
        for (int i = 1; i < size; i++) {
            MPI_Irecv(&value, 1, MPI_INT, i, 0, MPI_COMM_WORLD, &request);
            MPI_Wait(&request, &status);  // Ensure receive completes
            printf("Master received %d from process %d\n", value, i);
        }

    } else {
        // Worker receives using non-blocking receive
        MPI_Irecv(&value, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &request);
        MPI_Wait(&request, &status);  // Ensure receive completes

        value += 100;  // Simulate processing

        // Send result back to master using non-blocking send
        MPI_Isend(&value, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &request);
        MPI_Wait(&request, &status);  // Ensure send completes
    }

    MPI_Barrier(MPI_COMM_WORLD);  // Synchronize before ending time
    end_time = MPI_Wtime();

    if (rank == 0) {
        printf("Non-blocking Communication Time: %f seconds\n", end_time - start_time);
    }

    MPI_Finalize();
    return 0;
}

