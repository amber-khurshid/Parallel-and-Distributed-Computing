#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) {
    // Declare variables for rank and size
    int rank, size;
    // Start MPI
    MPI_Init(&argc, &argv);
    // Get my process rank
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    // Get total number of processes
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Set array size to 16
    const int arr_size = 16;
    // Array to hold all numbers
    int array[arr_size];
    // Pointer for worker's chunk
    int *local_array = NULL;
    // Variable to store chunk size for each worker
    int local_size;

    if (rank == 0) {
        // Master process (rank 0)
        // Fill array with numbers 1 to 16
        for (int i = 0; i < arr_size; i++) {
            array[i] = i + 1;
        }

        // Figure out how many workers we have
        int num_workers = size - 1;
        // Base size for each worker
        int base_size = arr_size / num_workers;
        // Extra elements to distribute
        int remainder = arr_size % num_workers;
        // Keep track of where we are in the array
        int offset = 0;

        // Send chunks to each worker
        for (int i = 1; i < size; i++) {
            // Give extra element to first few workers if needed
            local_size = base_size + (i <= remainder ? 1 : 0);
            // Send the chunk size to worker
            MPI_Send(&local_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            // Send the chunk of the array
            MPI_Send(&array[offset], local_size, MPI_INT, i, 1, MPI_COMM_WORLD);
            // Move to next chunk
            offset += local_size;
        }

        // Collect results from workers
        offset = 0;
        for (int i = 1; i < size; i++) {
            // Calculate chunk size again
            local_size = base_size + (i <= remainder ? 1 : 0);
            // Receive squared chunk from worker
            MPI_Recv(&array[offset], local_size, MPI_INT, i, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            // Move to next part of array
            offset += local_size;
        }

        // Print the final array
        printf("Final array: ");
        for (int i = 0; i < arr_size; i++) {
            printf("%d ", array[i]);
        }
        printf("\n");
    } else {
        // Worker processes (rank 1 and up)
        // Receive my chunk size from master
        MPI_Recv(&local_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        // Allocate memory for my chunk
        local_array = (int *)malloc(local_size * sizeof(int));
        // Receive my chunk of the array
        MPI_Recv(local_array, local_size, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // Square each number in my chunk
        for (int i = 0; i < local_size; i++) {
            local_array[i] *= local_array[i];
        }

        // Send squared chunk back to master
        MPI_Send(local_array, local_size, MPI_INT, 0, 2, MPI_COMM_WORLD);
        // Free the memory
        free(local_array);
    }

    // End MPI
    MPI_Finalize();
    return 0;
}
