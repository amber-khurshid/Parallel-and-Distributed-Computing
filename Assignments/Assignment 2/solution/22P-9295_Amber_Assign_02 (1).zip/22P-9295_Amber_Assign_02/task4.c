#include <mpi.h>
#include <stdio.h>
#include <stdbool.h>

// Define number of full cycles to complete
#define M 3

int main(int argc, char *argv[]) {
    int rank, size;
    int counter = 0;
    bool terminate = false;
    MPI_Status status;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);

    // Get the rank of the process
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    // Get total number of processes
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Ensure we have at least 4 processes
    if (size < 4) {
        if (rank == 0)
            printf("This program requires at least 4 processes.\n");
        MPI_Finalize();
        return 1;
    }

    // Calculate the ranks of next and previous processes in the ring
    int next = (rank + 1) % size;
    int prev = (rank - 1 + size) % size;

    // Logic for process 0 (the starter and controller of the ring)
    if (rank == 0) {
        int cycles = 0;

        // Start by sending counter to the next process
        counter = 0;
        MPI_Send(&counter, 1, MPI_INT, next, 0, MPI_COMM_WORLD);

        // Loop until termination condition is met
        while (!terminate) {
            // Receive counter from previous process
            MPI_Recv(&counter, 1, MPI_INT, prev, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

            // Increment counter
            counter++;

            // Count number of full cycles
            if (counter % size == 0)
                cycles++;

            // Check if M full cycles completed
            if (cycles >= M) {
                terminate = true;
                counter = -1; // Use -1 as termination flag
            }

            // Send updated counter or termination flag to next process
            MPI_Send(&counter, 1, MPI_INT, next, 0, MPI_COMM_WORLD);
        }

    } else {
        // Logic for all other processes in the ring
        while (!terminate) {
            // Receive counter from previous process
            MPI_Recv(&counter, 1, MPI_INT, prev, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

            // If counter is -1, terminate
            if (counter == -1) {
                terminate = true;
            } else {
                // Otherwise, increment counter
                counter++;
            }

            // Send counter (or termination flag) to next process
            MPI_Send(&counter, 1, MPI_INT, next, 0, MPI_COMM_WORLD);

            // Ensure termination if termination flag was received
            if (counter == -1)
                terminate = true;
        }
    }

    // Each process prints its termination message
    printf("Process %d exiting.\n", rank);

    // Finalize MPI environment
    MPI_Finalize();
    return 0;
}

