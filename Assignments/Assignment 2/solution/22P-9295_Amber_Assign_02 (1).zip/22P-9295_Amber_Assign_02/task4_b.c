#include <mpi.h>
#include <stdio.h>
#include <stdbool.h>

#define M 3  

int main(int argc, char *argv[]) {
    int rank, size;
    int counter_next = 0;
    int counter_prev = 0;
    bool terminate = false;
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size < 4) {
        if (rank == 0)
            printf("At least 4 processes required.\n");
        MPI_Finalize();
        return 1;
    }

    int next = (rank + 1) % size;
    int prev = (rank - 1 + size) % size;

    if (rank == 0) {
        int cycles = 0;
        counter_next = 0;
        // Start second counter for opposite direction
        counter_prev = 100;  

        // Send both directions
        MPI_Send(&counter_next, 1, MPI_INT, next, 0, MPI_COMM_WORLD);
        MPI_Send(&counter_prev, 1, MPI_INT, prev, 1, MPI_COMM_WORLD);

        while (!terminate) {
            // Receive both directions
            MPI_Recv(&counter_next, 1, MPI_INT, prev, 0, MPI_COMM_WORLD, &status);
            MPI_Recv(&counter_prev, 1, MPI_INT, next, 1, MPI_COMM_WORLD, &status);

            counter_next++;
            counter_prev++;

            if (counter_next % size == 0 && counter_prev % size == 0)
                cycles++;

            if (cycles >= M) {
                counter_next = -1;
                counter_prev = -1;
                terminate = true;
            }

            // Send both directions again
            MPI_Send(&counter_next, 1, MPI_INT, next, 0, MPI_COMM_WORLD);
            MPI_Send(&counter_prev, 1, MPI_INT, prev, 1, MPI_COMM_WORLD);
        }

    } else {
        while (!terminate) {
            // Receive both directions
            MPI_Recv(&counter_next, 1, MPI_INT, prev, 0, MPI_COMM_WORLD, &status);
            MPI_Recv(&counter_prev, 1, MPI_INT, next, 1, MPI_COMM_WORLD, &status);

            if (counter_next == -1 || counter_prev == -1) {
                counter_next = -1;
                counter_prev = -1;
                terminate = true;
            } else {
                counter_next++;
                counter_prev++;
            }

            // Send both directions again
            MPI_Send(&counter_next, 1, MPI_INT, next, 0, MPI_COMM_WORLD);
            MPI_Send(&counter_prev, 1, MPI_INT, prev, 1, MPI_COMM_WORLD);
        }
    }

    printf("Process %d exiting bi-directionally.\n", rank);
    MPI_Finalize();
    return 0;
}

