#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) {
    // Declare variables for rank and size
    int rank, size;
    // Start MPI
    MPI_Init(&argc, &argv);
    // Get my process rank
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    // Get total number of processes
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Set array size to 16
    const int arr_size = 16;
    // Array to hold all numbers
    int array[arr_size];
    // Pointer for worker's chunk
    int *local_array = NULL;
    // Variable to store chunk size for each worker
    int local_size;

    if (rank == 0) {
        // Master process (rank 0)
        // Fill array with numbers 1 to 16
        for (int i = 0; i < arr_size; i++) {
            array[i] = i + 1;
        }

        // Figure out how many workers we have
        int num_workers = size - 1;
        // Base size for each worker
        int base_size = arr_size / num_workers;
        // Extra elements to distribute
        int remainder = arr_size % num_workers;
        // Keep track of where we are in the array
        int offset = 0;

        // Create array for send requests
        MPI_Request *requests = (MPI_Request *)malloc(2 * num_workers * sizeof(MPI_Request));
        int req_count = 0;

        // Send chunks to each worker using non-blocking sends
        for (int i = 1; i < size; i++) {
            // Give extra element to first few workers if needed
            local_size = base_size + (i <= remainder ? 1 : 0);
            // Start sending chunk size
            MPI_Isend(&local_size, 1, MPI_INT, i, 0, MPI_COMM_WORLD, &requests[req_count++]);
            // Start sending chunk of the array
            MPI_Isend(&array[offset], local_size, MPI_INT, i, 1, MPI_COMM_WORLD, &requests[req_count++]);
            // Move to next chunk
            offset += local_size;
        }

        // Wait for all sends to finish
        MPI_Waitall(req_count, requests, MPI_STATUSES_IGNORE);

        // Reset for receiving
        req_count = 0;
        offset = 0;

        // Collect results from workers using non-blocking receives
        for (int i = 1; i < size; i++) {
            // Calculate chunk size again
            local_size = base_size + (i <= remainder ? 1 : 0);
            // Start receiving squared chunk
            MPI_Irecv(&array[offset], local_size, MPI_INT, i, 2, MPI_COMM_WORLD, &requests[req_count++]);
            // Move to next part of array
            offset += local_size;
        }

        // Wait for all receives to finish
        MPI_Waitall(req_count, requests, MPI_STATUSES_IGNORE);
        // Free request array
        free(requests);

        // Print the final array
        printf("Final array: ");
        for (int i = 0; i < arr_size; i++) {
            printf("%d ", array[i]);
        }
        printf("\n");
    } else {
        // Worker processes (rank 1 and up)
        // Create requests for receiving
        MPI_Request requests[2];
        // Start receiving chunk size
        MPI_Irecv(&local_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &requests[0]);
        // Wait for chunk size to arrive
        MPI_Wait(&requests[0], MPI_STATUS_IGNORE);
        // Allocate memory for my chunk
        local_array = (int *)malloc(local_size * sizeof(int));
        // Start receiving chunk of the array
        MPI_Irecv(local_array, local_size, MPI_INT, 0, 1, MPI_COMM_WORLD, &requests[1]);
        // Wait for chunk to arrive
        MPI_Wait(&requests[1], MPI_STATUS_IGNORE);

        // Square each number in my chunk
        for (int i = 0; i < local_size; i++) {
            local_array[i] *= local_array[i];
        }

        // Start sending squared chunk back to master
        MPI_Isend(local_array, local_size, MPI_INT, 0, 2, MPI_COMM_WORLD, &requests[0]);
        // Wait for send to finish
        MPI_Wait(&requests[0], MPI_STATUS_IGNORE);
        // Free the memory
        free(local_array);
    }

    // End MPI
    MPI_Finalize();
    return 0;
}
