#include <mpi.h>
#include <stdio.h>

#define SIZE 5

int main(int argc, char *argv[]) {
    int rank, size;
    int array1[SIZE] = {1, 2, 3, 4, 5};
    int array2[SIZE] = {6, 7, 8, 9, 10};
    MPI_Status status;

    // Initialize MPI environment
    MPI_Init(&argc, &argv);                 
    // Get current process rank
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);  
    // Get total number of processes 
    MPI_Comm_size(MPI_COMM_WORLD, &size);   

    if (size < 4) {
        if (rank == 0) {
            printf("This program requires at least 4 processes.\n");
        }
        MPI_Finalize();
        return 1;
    }

    if (rank == 0) {
        // Process 0 sends array1 to Process 1 with tag 10
        MPI_Send(array1, SIZE, MPI_INT, 1, 10, MPI_COMM_WORLD);
        // Process 0 sends array2 to Process 2 with tag 20
        MPI_Send(array2, SIZE, MPI_INT, 2, 20, MPI_COMM_WORLD);
    }

    else if (rank == 1) {
        int recv_array[SIZE];
        // Receive array1 from Process 0 with tag 10
        MPI_Recv(recv_array, SIZE, MPI_INT, 0, 10, MPI_COMM_WORLD, &status);

        // Process the array (e.g., sum)
        int sum1 = 0;
        for (int i = 0; i < SIZE; i++) {
            sum1 += recv_array[i];
        }

        // Send result to Process 3 with tag 30
        MPI_Send(&sum1, 1, MPI_INT, 3, 30, MPI_COMM_WORLD);
    }

    else if (rank == 2) {
        int recv_array[SIZE];
        // Receive array2 from Process 0 with tag 20
        MPI_Recv(recv_array, SIZE, MPI_INT, 0, 20, MPI_COMM_WORLD, &status);

        // Process the array (e.g., sum)
        int sum2 = 0;
        for (int i = 0; i < SIZE; i++) {
            sum2 += recv_array[i];
        }

        // Send result to Process 3 with tag 40
        MPI_Send(&sum2, 1, MPI_INT, 3, 40, MPI_COMM_WORLD);
    }

    else if (rank == 3) {
        int result1, result2;

        // Receive first result (from either Process 1 or 2)
        MPI_Recv(&result1, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        printf("Process 3 received result %d from process %d with tag %d\n", result1, status.MPI_SOURCE, status.MPI_TAG);

        // Receive second result
        MPI_Recv(&result2, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        printf("Process 3 received result %d from process %d with tag %d\n", result2, status.MPI_SOURCE, status.MPI_TAG);

        // Final aggregation
        int final_result = result1 + result2;
        printf("Final Aggregated Result: %d\n", final_result);
    }

    MPI_Finalize(); // Finalize the MPI environment
    return 0;
}

