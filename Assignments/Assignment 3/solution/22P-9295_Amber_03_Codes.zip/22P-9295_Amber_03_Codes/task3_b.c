#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char** argv) {

    int process_id, total_procs;
    int random_value;
    int gathered_values[6];
    int highest_value, total_sum;
    float avg_value;

    double start_time, end_time, duration_allgather, duration_reduce;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &process_id);
    MPI_Comm_size(MPI_COMM_WORLD, &total_procs);

    srand(time(NULL) + process_id);
    random_value = (rand() % 100) + 1;

    printf("Process %d generated: %d\n", process_id, random_value);

    // Timing MPI_Allgather
    start_time = MPI_Wtime();
    MPI_Allgather(&random_value, 1, MPI_INT, gathered_values, 1, MPI_INT, MPI_COMM_WORLD);
    end_time = MPI_Wtime();
    duration_allgather = end_time - start_time;

    // Timing MPI_Reduce
    start_time = MPI_Wtime();
    MPI_Reduce(&random_value, &highest_value, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
    end_time = MPI_Wtime();
    duration_reduce = end_time - start_time;

    // Total sum using Allreduce
    MPI_Allreduce(&random_value, &total_sum, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
    avg_value = total_sum / (float)total_procs;

    if (process_id == 0) {
        printf("\nSummary (Process 0) \n");
        printf("Maximum number: %d\n", highest_value);
        printf("MPI_Allgather: %.6f seconds (%d operations)\n", duration_allgather, total_procs);
        printf("MPI_Reduce   : %.6f seconds (%d operations)\n", duration_reduce, total_procs);
        printf("\n\n");
    }

    printf("Process %d: Average number: %.2f\n", process_id, avg_value);

    MPI_Finalize();
    return 0;
}

