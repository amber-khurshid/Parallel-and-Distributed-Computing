#include <mpi.h>
#include <stdio.h>
#include <stddef.h>


int main(int argc, char** argv) {
    MPI_Init(NULL, NULL);
    
    int world_rank, world_size;
    
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // Creating buffers for sending and receiving data
    int sendbuf[16]; 
    
    // receive buffer for 4 integers per process
    int recvbuf[4];  
    
    // buffer to collect all results in process 0
    int recv_all[16]; 

    // Setting up initial values in process 0
    if (world_rank == 0) {
        for (int i = 0; i < 16; i++) {

            sendbuf[i] = i + 1; 
        }
    }

    // Distributing data from process 0 to all processes
    MPI_Scatter(sendbuf, 4, MPI_INT, recvbuf, 4, MPI_INT, 0, MPI_COMM_WORLD);

    // Displaying the values  process received
    for (int i = 0; i < 4; i++) {
        printf("Process %d received value %d: %d\n", world_rank, i, recvbuf[i]);
    }

    // Multiplying received chunk by 2 in each process
    for (int i = 0; i < 4; i++) {

        recvbuf[i] *= 2;
    }

    // Collecting updated data back to process 0
    MPI_Gather(recvbuf, 4, MPI_INT, recv_all, 4, MPI_INT, 0, MPI_COMM_WORLD);

    // Printing  final array from process 0
    if (world_rank == 0) {
        // Displaying  final array header
        printf("Final array on process 0:\n");
        

        for (int i = 0; i < 16; i++) {
            // Printing each element of  array
            printf("%d ", recv_all[i]);
        }
        

        printf("\n");
    }


    MPI_Finalize();
    

    return 0;
}
